import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import linregress

def draw_plot():
    # Read data from file
    df = pd.read_csv("epa-sea-level.csv")
    print("read csv file")

    # Create scatter plot
    # Use matplotlib to create a scatter plot using the "Year" column as the x-axis and the "CSIRO Adjusted Sea Level" column as the y-axix.
    x= df["Year"]
    y= df["CSIRO Adjusted Sea Level"]
    plt.scatter(x, y)

    # Create first line of best fit
    # Use the linregress function from scipi.stats to get the slope and y-intercept of the line of best fit. Plot the line of best fit over the top of the scatter plot. Make the line go through the year 2050 to predict the sea level rise in 2050.

    slope, intercept, r_value, p_value, std_err = linregress(x, y)

    first_best_x = list(range(1880, 2050))
    first_best_y = []

    for year in first_best_x:
      first_best_y.append(intercept + slope * year)
        
    plt.plot(first_best_x, first_best_y, 'r', label= 'Best Fit Line 1')
    print("finish first scatter") 

    # Create second line of best fit
    # Plot a new line of best fit just using the data from year 2000 through the most recent year in the dataset. Make the line also go through the year 2050 to predict the sea level rise in 2050 if the rate of rise continues as it has since the year 2000.

    xfuture = df[df['Year'] >= 2000] ['Year']
    yfuture = df[df['Year'] >= 2000] ['CSIRO Adjusted Sea Level']

    newslope, newintercept, r_value, p_value, std_err = linregress(xfuture, yfuture)
    #newslope = newfit.slope
    #newintercept = newfit.intercept

    # Create Second line of Best fit
    # SECOND best fit for year 2000 onwards so shall have new slope and intercept
    second_best_x = list(range(2000, 2050))
    second_best_y = []

    for second_best in second_best_x:
      second_best_y.append(newintercept + newslope * second_best)
        
    plt.plot(second_best_x, second_best_y, 'r', label = 'Best Fit Line 2', color='green')
    plt.legend()
    #plt.show()
    
    # Add labels and title
    # The x label should be "Year", the y label should be "Sea Level (inches)", and the title should be "Rise in Sea Level".
    plt.xlabel("Year")
    plt.ylabel("Sea Level (inches)")
    plt.title("Rise in Sea Level")

    # Save plot and return data for testing (DO NOT MODIFY)
    plt.savefig('sea_level_plot.png')
    return plt.gca()